/****************************************************************************
 * Copyright (c) 2017 liangxie
 * 
 * http://liangxiegame.com
 * https://github.com/liangxiegame/QFramework
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 ****************************************************************************/

using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace QFramework
{
	public class Main : MonoBehaviour
	{

		
#if UNITY_EDITOR
		[UnityEditor.Callbacks.DidReloadScripts]
#endif
		private static void OnReloadScrips()
		{
			Log.I("on scrip reload");

			if (SyncConst.IsQFramework)
			{
				foreach (var srcRule in SyncConst.SrcRules)
				{
					var srcContent = srcRule.DstContent;
					srcRule.DstContent = srcRule.SrcContent;
					srcRule.SrcContent = srcContent;
				}
			}

			foreach (var dirRules in SyncConst.DirRules)
			{
				if (SyncConst.IsQFramework)
				{
					var srcContent = dirRules.DstContent;
					dirRules.DstContent = dirRules.SrcContent;
					dirRules.SrcContent = srcContent;
				}

				CopyToFolder(SyncConst.SRC_BASE_DIR.CombinePath(dirRules.SrcContent),
					SyncConst.DST_BASE_DIR.CombinePath(dirRules.DstContent), SyncConst.SrcRules);
			}
		}

		private static void CopyToFolder(string curSrcRootDir, string curDstRootDir, List<Rule> rules)
		{
			IOUtils.CreateDirIfNotExists(curDstRootDir);

			var srcFileNames = Directory.GetFiles(curSrcRootDir);

			foreach (var fullFileName in srcFileNames)
			{
				var fileName = fullFileName.Replace(curSrcRootDir, "").Replace("/", "");
				var dstFileName = curDstRootDir.CombinePath(fileName);
				if (fullFileName.EndsWith(".cs"))
				{
					if (fileName.EndsWith("Rules.cs") || fileName.EndsWith("Log.cs"))
					{

					}
					else
					{
						ReplaceFile(fullFileName, dstFileName, rules);
					}
				}
				else
				{
					if (fileName.EndsWith("Log.dll") || fileName.EndsWith(".meta"))
					{
					}
					else
					{
						File.Copy(fullFileName, dstFileName, true);
					}
				}
			}

			var srcDirNames = Directory.GetDirectories(curSrcRootDir);

			foreach (var fullDirName in srcDirNames)
			{
				var dirname = fullDirName.Replace(curSrcRootDir, "").Replace("/", "");
				CopyToFolder(fullDirName, curDstRootDir + "/" + dirname, rules);
			}
		}

		private static void ReplaceFile(string srcFile, string dstFile, List<Rule> rules)
		{
			var reader = File.OpenText(srcFile);
            
			var fileText = reader.ReadToEnd();
            
			reader.Close();

			fileText = rules.Where(replacePair => !replacePair.SrcContent.IsNullOrEmpty()).Aggregate(fileText,
				(current, replacePair) => current.Replace(replacePair.SrcContent, replacePair.DstContent));


			File.WriteAllText(dstFile,fileText);
		}
	}
}