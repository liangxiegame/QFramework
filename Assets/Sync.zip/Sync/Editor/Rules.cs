
using System.Collections.Generic;
using UnityEngine;

public class Rule
{
    public string SrcContent;
    public string DstContent;
}

public class SyncConst
{
    public static bool IsQFramework = true;

    public static string SRC_BASE_DIR = Application.dataPath + "/";

    public static string DST_BASE_DIR
    {
        get
        {
            return IsQFramework ? "/Users/liangxie/Documents/Career/putao_work/RoboBlock/Client/Assets/" : "/Users/liangxie/Documents/Career/Product/SyncProject/QFramework/Assets/";
        }
    }
    
    public static List<Rule> DirRules = new List<Rule>()
    {
        new Rule()
        {
            SrcContent = "Sync",
            DstContent = "Sync",
        },

        new Rule()
        {
            SrcContent = "PTUGame/PTCore/Libs",
            DstContent = "QFramework/Core/CSharp/Libs",
        },        
        new Rule()
        {
            SrcContent = "PTUGame/PTCore/CSharp/NodeSystem",
            DstContent = "QFramework/Core/CSharp/NodeSystem",
        },        
        new Rule()
        {
            SrcContent = "PTUGame/PTCore/CSharp/Utils",
            DstContent = "QFramework/Core/CSharp/Utils",
        },         
        new Rule()
        {
            SrcContent = "PTUGame/PTCore/Unity/AStar",
            DstContent = "QFramework/Core/Unity/AStar",
        },        
        new Rule()
        {
            SrcContent = "PTUGame/PTCore/Unity/CI",
            DstContent = "QFramework/Core/Unity/CI",
        },     
        new Rule()
        {
            SrcContent = "PTUGame/PTCore/Unity/Utils",
            DstContent = "QFramework/Core/Unity/Utils",
        },             
    };


    public static List<Rule> SrcRules = new List<Rule>()
    {
        new Rule()
        {
            SrcContent = "IsQFramework = false;",
            DstContent = "IsQFramework = true;"
        },      
        new Rule()
        {
            SrcContent = "PTFSM",
            DstContent = "QFSM"
        },
        new Rule()
        {
            SrcContent = " PTGame.Framework",
            DstContent = " QFramework",
        },        
        new Rule()
        {
            SrcContent = "ouyanggongping@putao.com",
            DstContent = "snowcold",
        },       
        new Rule()
        {
            SrcContent = "maoling@putao.com ",
            DstContent = "imagicbell",
        },        
        new Rule()
        {
            SrcContent = "PTMsg",
            DstContent = "QMsg",
        },        
        new Rule()
        {
            SrcContent = "PTMgrId",
            DstContent = "QMgrId",
        },
        new Rule()
        {
            SrcContent = "PTMgrBehaviour",
            DstContent = "QMgrBehaviour",
        },  
        new Rule()
        {
            SrcContent = "PTSingletonProperty",
            DstContent = "QSingletonProperty",
        },          
        new Rule()
        {
            SrcContent = "PTSingleton",
            DstContent = "QSingleton",
        },   
        new Rule()
        {
            SrcContent = "PTMonoSingleton",
            DstContent = "QMonoSingleton",
        },        
        new Rule()
        {
            SrcContent = "PTEventSystem",
            DstContent = "QEventSystem",
        },         
        new Rule()
        {
            SrcContent = "PTUIManager",
            DstContent = "QUIManager",
        },      
        new Rule()
        {
            SrcContent = "",
            DstContent = " * http://liangxiegame.com\n",
        },
        new Rule()
        {
            SrcContent = "2017 liqingyun@putao.com",
            DstContent = "2017 liangxie",
        },     
        new Rule()
        {
            SrcContent = "PTUICameraUtil",
            DstContent = "QUICameraUtil",
        },
        new Rule()
        {
            SrcContent = " ****************************************************************************/",
            DstContent = " * \n * http://liangxiegame.com\n * https://github.com/liangxiegame/QFramework\n * \n * Permission is hereby granted, free of charge, to any person obtaining a copy\n * of this software and associated documentation files (the \"Software\"), to deal\n * in the Software without restriction, including without limitation the rights\n * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n * copies of the Software, and to permit persons to whom the Software is\n * furnished to do so, subject to the following conditions:\n * \n * The above copyright notice and this permission notice shall be included in\n * all copies or substantial portions of the Software.\n * \n * THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n * THE SOFTWARE.\n ****************************************************************************/",
        },
        new Rule()
        {
            SrcContent = "",
            DstContent = " * THE SOFTWARE.\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n",
        },        
        new Rule()
        {
            SrcContent = "",
            DstContent = " * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n",
        },        
        new Rule()
        {
            SrcContent = "",
            DstContent = " * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * all copies or substantial portions of the Software.\n",
        },        
        new Rule()
        {
            SrcContent = "",
            DstContent = " * The above copyright notice and this permission notice shall be included in\n",
        },      
        new Rule()
        {
            SrcContent = "",
            DstContent = " * furnished to do so, subject to the following conditions:\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * copies of the Software, and to permit persons to whom the Software is\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * in the Software without restriction, including without limitation the rights\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * of this software and associated documentation files (the \"Software\"), to deal\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * Permission is hereby granted, free of charge, to any person obtaining a copy\n",
        },       
        new Rule()
        {
            SrcContent = "",
            DstContent = " * https://github.com/liangxiegame/QFramework\n",
        },   
        new Rule()
        {
            SrcContent = "",
            DstContent = " * \n",
        }, 
    };
}
