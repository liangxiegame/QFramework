#### 基本功能:

* 遮罩
  * 圆形遮罩：在全屏遮罩上挂载 CircleGuideCtrl.cs 脚本，并选择Target，示例场景参考Example_CircleMask.unity
  * 方形遮罩：在全屏遮罩上挂载 RectGuideCtrl.cs 脚本，并选择Target，示例场景参考Example_RectMask.unity
* 条件
* 触发

#### 要求:

* 独立的不与任何 UI 系统耦合

* 方便易用

* 可 Hard Code,可配表。

* 最好支持热更新。

  ​

#### 一些参考资料:

* https://github.com/GaoKaiHaHa/MyUnityFrameWork
* https://github.com/nashnie/Guide







