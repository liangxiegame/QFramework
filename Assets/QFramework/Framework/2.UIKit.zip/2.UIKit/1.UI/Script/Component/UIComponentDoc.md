>作者：vin129     邮箱：515019721@qq.com

# UIComponent

# 继承关系

继承自：UIElement

# 描述

> Abstract Class
>
> 可被UICodeGenerator 处理
>
> UI组件脚本基类

# 抽象&重载方法

|                   |                             |
| ----------------- | --------------------------- |
| **GetUIMarkType** | return UIMarkType.Component |
