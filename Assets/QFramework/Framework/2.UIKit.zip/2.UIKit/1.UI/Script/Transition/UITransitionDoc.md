作者：SilenceT     邮箱：499683507@qq.com

# UITransition

# 继承关系

实现接口：NodeAction、ITransition

# 描述

UIPanel切换显示行为的脚本的抽象类

# **属性**

|                         |               |
| ----------------------- | ------------- |
| **UIPanel FromPanel**   | UIMark类型    |
| **Action InCompleted**  | 注释          |
| **Action OutCompleted** | 组件Transform |

# **方法**

|        |                    |
| ------ | ------------------ |
| **Do** | 处理切换的行为动作 |

