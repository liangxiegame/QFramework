>作者：vin129     邮箱：515019721@qq.com

# UIPointerUpEventListener

# 继承关系

继承自：MonoBehaviour

实现接口：IPointerUpHandler

# 描述

> 挂载组件
>
> 监听点击抬起事件

# 公共属性

|                      |          |
| -------------------- | -------- |
| **OnPointerUpEvent** | 抬起事件 |

# 静态方法

|                         |                                   |
| ----------------------- | --------------------------------- |
| **Get**                 | 执行 **CheckAndAddListener** 方法 |
| **CheckAndAddListener** | 检查并添加此组件                  |

# 实现接口

|                 |                           |
| --------------- | ------------------------- |
| **OnPointerUp** | 执行 **OnPointerUpEvent** |

