﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefab
{
    public class Bar : MonoBehaviour
    {
    }
}
