namespace Invert.Data
{
    public interface IDataRecordRemoving
    {
        void RecordRemoving(IDataRecord record);
    }
}