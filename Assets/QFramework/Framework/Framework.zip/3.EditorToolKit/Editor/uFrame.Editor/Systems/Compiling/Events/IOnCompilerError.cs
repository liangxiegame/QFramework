namespace QF.GraphDesigner
{
    public interface IOnCompilerError
    {
        void Error(ErrorInfo info);
    }
}