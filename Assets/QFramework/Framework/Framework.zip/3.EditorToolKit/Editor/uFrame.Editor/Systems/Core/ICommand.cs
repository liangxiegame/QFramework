namespace QF.GraphDesigner
{
    public interface ICommand
    {
        string Title { get; set; }
    }
}