namespace QF.GraphDesigner
{
    public class ProxySection : Section
    {
        public ProxySection(string name, SectionVisibility visibility) : base(name, visibility)
        {
        }
    }
}