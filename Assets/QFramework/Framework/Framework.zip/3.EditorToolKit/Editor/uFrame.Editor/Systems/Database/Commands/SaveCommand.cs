namespace QF.GraphDesigner
{
    public class SaveCommand : Command
    {
        
    }
}