﻿namespace QF.GraphDesigner.Pro
{
    public interface ITemplate
    {

    }
}