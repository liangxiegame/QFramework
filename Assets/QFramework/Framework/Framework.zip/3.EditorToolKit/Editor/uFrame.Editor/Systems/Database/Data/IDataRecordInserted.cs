namespace Invert.Data
{
    public interface IDataRecordInserted
    {
        void RecordInserted(IDataRecord record);
    }
}