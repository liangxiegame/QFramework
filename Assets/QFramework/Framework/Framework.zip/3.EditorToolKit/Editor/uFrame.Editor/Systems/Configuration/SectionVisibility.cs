namespace QF.GraphDesigner
{
    public enum SectionVisibility
    {
        Always,
        WhenNodeIsFilter,
        WhenNodeIsNotFilter
    }
}