namespace QF.GraphDesigner
{
    //public interface IMemberItemGenerator : IMemberGenerator
    //{
    //    object ItemObject { get; set; }
        
    //}
}