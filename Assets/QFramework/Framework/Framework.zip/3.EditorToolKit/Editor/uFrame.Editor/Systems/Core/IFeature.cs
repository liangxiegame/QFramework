namespace QF.GraphDesigner
{
    public interface IFeature
    {
        
    }
}