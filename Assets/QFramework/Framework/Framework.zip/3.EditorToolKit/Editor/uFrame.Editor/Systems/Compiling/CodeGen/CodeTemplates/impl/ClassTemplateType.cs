namespace QF.GraphDesigner
{
    public enum ClassTemplateType
    {
        BaseClass,
        Copy,
    }
}