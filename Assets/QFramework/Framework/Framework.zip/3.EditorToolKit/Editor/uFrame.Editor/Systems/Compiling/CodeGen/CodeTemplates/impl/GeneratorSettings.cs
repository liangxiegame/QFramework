using System;
using UnityEngine;

namespace QF.GraphDesigner
{
    public class GeneratorSettings
    {

    }
}