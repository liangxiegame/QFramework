namespace QF.GraphDesigner
{
    public enum InspectorType
    {
        Auto,
        TextArea,
        TypeSelection,
        GraphItems
    }
}