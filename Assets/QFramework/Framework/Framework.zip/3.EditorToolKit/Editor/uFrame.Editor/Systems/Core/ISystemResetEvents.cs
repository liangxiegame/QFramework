namespace QF.GraphDesigner
{
    public interface ISystemResetEvents
    {
        void SystemResetting();
        void SystemRestarted();
    }
}