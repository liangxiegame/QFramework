using System;

namespace QF.GraphDesigner
{
    public class TemplateComplete : Attribute
    {

    }
}