namespace QF.GraphDesigner
{
    /// <summary>
    /// Add this to any command that might cause any output paths to change
    /// </summary>
    public interface IFileSyncCommand
    {
        
    }
}