﻿using QF.GraphDesigner;

public class StepCommand : Command
{

}