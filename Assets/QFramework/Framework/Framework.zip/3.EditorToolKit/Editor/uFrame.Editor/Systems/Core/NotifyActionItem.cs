using System;

namespace QF.GraphDesigner
{
    public class NotifyActionItem
    {
        public string Title { get; set; }
        public System.Action Action { get; set; }
    }
}