namespace QF.GraphDesigner
{
    public interface IDocumentable : IDiagramNodeItem
    {
        
    }
}