using System;

namespace QF.GraphDesigner
{
    public class TemplateSetup : Attribute
    {

    }
}