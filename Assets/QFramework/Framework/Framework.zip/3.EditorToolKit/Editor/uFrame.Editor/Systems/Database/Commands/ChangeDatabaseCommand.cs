namespace QF.GraphDesigner
{
    public class ChangeDatabaseCommand : Command
    {
       
    }
}