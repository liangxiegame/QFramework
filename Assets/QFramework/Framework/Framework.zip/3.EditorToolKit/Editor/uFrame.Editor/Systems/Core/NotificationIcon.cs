namespace QF.GraphDesigner
{
    public enum NotificationIcon
    {
        Info,
        Error,
        Warning
    }
}