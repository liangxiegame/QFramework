namespace QF.GraphDesigner
{
    public class InsideAll : Inside
    {
        public InsideAll() : base(TemplateLocation.Both)
        {
        }
    }
}