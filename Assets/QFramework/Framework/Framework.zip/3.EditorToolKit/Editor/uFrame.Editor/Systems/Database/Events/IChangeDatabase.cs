namespace QF.GraphDesigner
{
    public interface IChangeDatabase
    {
        void ChangeDatabase(IGraphConfiguration configuration);
    }
}