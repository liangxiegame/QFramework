namespace QF.GraphDesigner
{
    public class TagConfig
    {
        public string Name { get; set; }
    }
}