namespace QF.GraphDesigner
{
    public class _TEMPLATETYPE_
    {

        public virtual string TheType(TemplateContext context)
        {
            return "void";
        }
    }
}