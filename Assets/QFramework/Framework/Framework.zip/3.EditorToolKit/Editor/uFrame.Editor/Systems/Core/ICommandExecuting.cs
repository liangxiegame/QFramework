namespace QF.GraphDesigner
{
    public interface ICommandExecuting
    {
        void CommandExecuting(ICommand command);
    }
}