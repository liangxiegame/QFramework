﻿namespace QF.GraphDesigner
{
    public interface IDiagramPlugin : ICorePlugin
    {
        
    }
}