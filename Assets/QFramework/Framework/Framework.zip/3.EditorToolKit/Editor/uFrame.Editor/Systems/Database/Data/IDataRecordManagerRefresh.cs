namespace Invert.Data
{
    public interface IDataRecordManagerRefresh
    {
        void ManagerRefreshed(IDataRecordManager manager);
    }
}