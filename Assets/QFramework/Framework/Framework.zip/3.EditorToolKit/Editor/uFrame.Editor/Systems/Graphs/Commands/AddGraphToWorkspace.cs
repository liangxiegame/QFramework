using QF.GraphDesigner;

public class AddGraphToWorkspace : Command
{

}