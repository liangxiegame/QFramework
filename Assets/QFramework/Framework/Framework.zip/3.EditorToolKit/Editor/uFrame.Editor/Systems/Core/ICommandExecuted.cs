namespace QF.GraphDesigner
{
    public interface ICommandExecuted
    {
        void CommandExecuted(ICommand command);
    }
}