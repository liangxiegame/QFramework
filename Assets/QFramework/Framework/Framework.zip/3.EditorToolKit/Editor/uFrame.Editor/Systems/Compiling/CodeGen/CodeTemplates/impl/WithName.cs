namespace QF.GraphDesigner
{
    public class WithName : WithNameFormat
    {
        public WithName() : base("{0}")
        {
        }
    }
}