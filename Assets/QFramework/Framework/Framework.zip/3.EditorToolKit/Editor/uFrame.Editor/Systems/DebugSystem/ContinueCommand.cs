﻿using QF.GraphDesigner;

public class ContinueCommand : Command
{

}