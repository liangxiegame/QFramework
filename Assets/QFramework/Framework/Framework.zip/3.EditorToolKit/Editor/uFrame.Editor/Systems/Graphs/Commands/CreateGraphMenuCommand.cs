using QF.GraphDesigner;

public class CreateGraphMenuCommand : Command
{

}