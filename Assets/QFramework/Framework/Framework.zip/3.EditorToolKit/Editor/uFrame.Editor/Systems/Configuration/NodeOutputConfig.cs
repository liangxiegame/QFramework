namespace QF.GraphDesigner
{
    public class NodeOutputConfig
    {
        
    }
}