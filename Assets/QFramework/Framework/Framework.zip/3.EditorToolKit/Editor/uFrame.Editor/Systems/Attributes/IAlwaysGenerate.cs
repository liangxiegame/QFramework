using Invert.Data;

namespace QF.GraphDesigner
{
    public interface IOnDemandTemplate : IClassTemplate
    {
        
    }
    public interface IAlwaysGenerate : IDataRecord
    {

    }
}