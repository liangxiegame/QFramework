namespace QF.GraphDesigner
{
    public enum ConnectorStyle
    {
        Triangle,
        Circle
    }
}