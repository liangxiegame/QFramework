namespace Invert.Data
{
    public interface IDataRecordRemoved
    {
        void RecordRemoved(IDataRecord record);
    }
}