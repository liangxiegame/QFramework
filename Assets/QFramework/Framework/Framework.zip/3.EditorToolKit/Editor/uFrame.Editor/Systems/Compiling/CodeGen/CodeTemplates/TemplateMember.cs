using System;

namespace QF.GraphDesigner.Pro
{
    public class TemplateMember : Attribute
    {
        public string Group { get; set; }

    }
}