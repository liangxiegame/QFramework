namespace QF.GraphDesigner
{
    public interface ITemplateCustomFilename
    {
        string Filename { get; }
    }
}