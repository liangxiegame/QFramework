namespace QF.GraphDesigner
{
    public enum ValidatorType
    {
        Info,
        Warning,
        Error
    }
}