namespace QF.GraphDesigner
{
    public interface IShowExceptionDetails
    {
        void ShowExceptionDetails(Problem problem);
    }
}