namespace QF.GraphDesigner
{
    public class SaveAndCompileCommand : Command
    {
        public bool ForceCompileAll { get; set; }
    }
}