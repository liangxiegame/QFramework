作者：SilenceT     邮箱：499683507@qq.com

# IMark

# 接口

# 描述

**UMark** 自身资源管理脚本的基础接口

# 结构体

| **UIMarkType**      | UIMark类型          |
| ------------------- | ------------------- |
| DefaultUnityElement | 默认的Unity元素类型 |
| Element             | 元素                |
| Component           | 组件                |



# **属性**

| String ComponentName | 组件名称         |
| -------------------- | ---------------- |
| String Comment       | 注释             |
| String Transform     | 该组件tranform值 |



# **方法**

|                   |                    |
| ----------------- | ------------------ |
| **GetUIMarkType** | **获取UIMark类型** |

