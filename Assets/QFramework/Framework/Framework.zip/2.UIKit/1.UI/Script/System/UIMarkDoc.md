作者：SilenceT     邮箱：499683507@qq.com

# UIMark

# 继承关系

实现接口：MonoBehaviour、IMark

# 描述

管理UIMark自身属性信息

# **属性**

|                            |               |
| -------------------------- | ------------- |
| UIMarkType MarkType        | UIMark类型    |
| String Comment             | 注释          |
| Transform Transform        | 组件Transform |
| String CustomComponentName | 组件名称      |

# **方法**

|                   |                    |
| ----------------- | ------------------ |
| **GetUIMarkType** | **获取UIMark类型** |

