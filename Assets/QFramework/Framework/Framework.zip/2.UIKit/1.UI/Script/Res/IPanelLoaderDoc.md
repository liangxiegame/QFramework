>作者：vin129     邮箱：515019721@qq.com

# IPanelLoader

# 接口

# 描述

> **UIPanel** 自身资源管理脚本的基础接口

# 方法

|                     |            |
| ------------------- | ---------- |
| **LoadPanelPrefab** | 加载UI资源 |
| **Unload**          | 卸载、回收 |

