>作者：vin129     邮箱：515019721@qq.com

# QUICameraUtil

# 继承关系

无

# 描述

> UICamera 工具集
>

# 静态属性

|              |                                        |
| ------------ | -------------------------------------- |
| **UICamera** | return **UIManager.Instance.UICamera** |

# 静态方法

|                         |                                             |
| ----------------------- | ------------------------------------------- |
| **SetPerspectiveMode**  | 透视，改变相机 **orthographic** 为**false** |
| **SetOrthographicMode** | 正交，改变相机 **orthographic** 为**true**  |
| **CaptureCamera**       | 截屏，返回 **Texture2D**                    |

