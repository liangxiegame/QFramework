>作者：vin129     邮箱：515019721@qq.com

# IManager

# 接口

# 描述

> UIKit 中 实现Manager of Manager 的基础接口
>
> 实现 事件/消息 监听机制

# 方法

|                   |          |
| ----------------- | -------- |
| **Init**          | 初始化   |
| **RegisterEvent** | 注册事件 |
| **UnRegistEvent** | 注销事件 |
| **SendEvent**     | 发送事件 |
| **SendMsg**       | 发送消息 |

