### RefCounter 模块简介:

简单计数器