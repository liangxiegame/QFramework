namespace QF.MVVM
{
     #if !NETFX_CORE
    public enum NotifyCollectionChangedAction
    {
        Reset,
        Add,
        Move,
        Remove,
        Replace
    }
#endif
}