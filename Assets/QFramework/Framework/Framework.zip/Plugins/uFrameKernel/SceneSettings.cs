namespace uFrame.Kernel
{
    public class SceneSettings<T> : ISceneSettings where T : IScene
    {

    }

    public interface ISceneSettings
    {
    }
}