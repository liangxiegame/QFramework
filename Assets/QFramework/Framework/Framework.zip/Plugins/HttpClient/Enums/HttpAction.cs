﻿
namespace CI.HttpClient
{
    public enum HttpAction
    {
        Delete,
        Get,
        Patch,
        Post,
        Put
    }
}