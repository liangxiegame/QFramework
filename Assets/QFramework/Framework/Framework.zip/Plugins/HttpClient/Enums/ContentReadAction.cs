﻿
namespace CI.HttpClient
{
    public enum ContentReadAction
    {
        Multi,
        ByteArray,
        Stream
    }
}