﻿using System;
using System.Collections;
using System.Collections.Generic;
using MultyFramework;
using UnityEngine;

namespace QFramework
{
	[Framework(EnvironmentType.Runtime)]    //标记支持的环境
	public class MutiFrameworkSupport : UpdateFramework
	{
		private string _name = "QFramework";
		private int _priority;

		// Use this for initialization
		void Start()
		{

		}

		// Update is called once per frame
		void Update()
		{

		}

		protected override void OnUpdate()
		{
			throw new System.NotImplementedException();
		}

		public override string name
		{
			get { return _name; }
		}

		public override int priority
		{
			get { return _priority; }
		}

		protected override void OnStartup()
		{
		}

		protected override void OnDispose()
		{

		}
	}
}
