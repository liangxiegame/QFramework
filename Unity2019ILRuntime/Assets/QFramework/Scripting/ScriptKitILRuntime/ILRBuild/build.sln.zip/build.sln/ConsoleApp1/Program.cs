﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length >= 4)
            {
                var arg1 = args[0];
                var arg2 = args[1];
                var arg3 = args[2];
                var arg4 = args[3];
                //var arg1 = "E:/Jiyu_work/TheGodClient/TheGod/Assets";
                //var arg2 = "E:/Jiyu_work/TheGodClient/TheGod/Assets/StreamingAssets";
                foreach (var a in args)
                {
                    Console.WriteLine("参数:" + a);
                }
                var result = ScriptBiuld_Service.BuildDLL_DotNet(arg1, arg2,arg3,arg4);

                if(result == ScriptBiuld_Service.BuildStatus.Success)
                {
                    Console.WriteLine("退出");
                    Thread.Sleep(500);
                    System.Diagnostics.Process.GetCurrentProcess().Close();
                }
                else
                {
                    Console.ReadLine();
                }
              
            }
            else
            {
                Console.WriteLine("没有传参");
                Console.WriteLine("退出");
                Thread.Sleep(500);
                System.Diagnostics.Process.GetCurrentProcess().Close();
            }
           
        }
    }
}
